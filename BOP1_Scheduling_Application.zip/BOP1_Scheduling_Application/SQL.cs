﻿using MySql.Data.MySqlClient;
using System.Data;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace BOP1_Scheduling_Application
{
     public class SQL
    {       
        public static string myConnectionString = "server=3.227.166.251;database=U05lUM;user=U05lUM;pwd=53688540322";
        MySqlConnection Conn = new MySqlConnection(myConnectionString);
        MainForm MainForm = new MainForm();
        MySqlDataReader mdr;
        public static List<int> AppointmentIDList = new List<int>();
        public static List<int> CustomerIDList = new List<int>();
        public static List<int> AddressIDList = new List<int>();
        public static int AppointmentIndex = -1;
        public static int CustomerIndex = -2;
        public static int AddressIndex = -1;
        Random random = new Random();
        public static DateTime Open = DateTime.SpecifyKind(Convert.ToDateTime("09:00:00"), DateTimeKind.Local);
        public static DateTime Close = DateTime.SpecifyKind(Convert.ToDateTime("17:00:00"), DateTimeKind.Local);


        public void FillAppointmentList()
        {
            Conn.Open();     
            string Query = "SELECT appointmentId FROM U05lUM.appointment;";
            MySqlCommand command = new MySqlCommand(Query, Conn);
             using (mdr = command.ExecuteReader())
            {
                while (mdr.Read())
                {
                    int id = mdr.GetInt32("appointmentId");
                    AppointmentIDList.Add(id);
                }
            }
            Conn.Close();
        }

        public void FillCustomerList()
        {
            Conn.Open();
            string Query = "Select customerId from U05lUM.customer;";
            MySqlCommand command = new MySqlCommand(Query, Conn);
            using (mdr = command.ExecuteReader())
            {
                while (mdr.Read())
                {
                    int id = mdr.GetInt32("customerId");
                    CustomerIDList.Add(id);
                }
            }
            Conn.Close();
        }
        public void FillAddressIDList() {
            Conn.Open();
            string Query = "Select addressId from U05lUM.address;";
            MySqlCommand command = new MySqlCommand(Query, Conn);
            using (mdr = command.ExecuteReader())
            {
                while (mdr.Read())
                {
                    int id = mdr.GetInt32("addressId");
                    AddressIDList.Add(id);
                }
            }
            Conn.Close();
        }
        public void MySQL(string s)
        {
            MySqlCommand Insert = new MySqlCommand(s, Conn);
            MySqlDataReader mdr;
            Conn.Open();
            mdr = Insert.ExecuteReader();
            Conn.Close();
        }
        public void AddAppointment(Appointment Appt)
        {
            
            MySQL("INSERT INTO `U05lUM`.`appointment` (`appointmentId`, `customerId`, `userId`, `title`, `description`, `location`, `contact`, `type`, `url`, `start`, `end`, `createDate`, `createdBy`, `lastUpdate`, `lastUpdateBy`) " +
                "VALUES('" + Appt.AppointmentID + "', '"+Appt.CustomerID+"', '"+Appt.UserID+"', '"+Appt.Title+"', '"+Appt.Description+"', '"+Appt.Location+"', '"+Appt.Contact+"', '"+Appt.Type+"', '"+Appt.URL+"', '"+Appt.Start.ToString("yyyy-MM-dd HH:mm:ss")+"'" +
                ", '"+Appt.End.ToString("yyyy-MM-dd HH:mm:ss")+"', '"+Appt.CreateDate.ToString("yyyy-MM-dd HH:mm:ss")+"', '"+Appt.CreatedBy+"', '"+Appt.LastUpdate.ToString("yyyy-MM-dd HH:mm:ss")+"', '"+Appt.LastUpdatedBy+"'); ");
        }

        public void UpdateAppointment(Appointment Appt)
        {
            MySQL("UPDATE `U05lUM`.`appointment` SET `customerId` = '"+Appt.CustomerID+"', `type` = '"+Appt.Type+"', `start` = '"+Appt.Start.ToString("yyyy-MM-dd HH:mm:ss")+"', `end` = '"+Appt.End.ToString("yyyy-MM-dd HH:mm:ss")+"', `lastUpdate` = '"+Appt.LastUpdate.ToString("yyyy-MM-dd HH:mm:ss")+"', `lastUpdateBy` = '"+Appt.LastUpdatedBy+"' WHERE(`appointmentId` = '"+Appt.AppointmentID+"'); ");
        }

        public void DeleteAppointment(string ApptID)
        {
            MySQL("DELETE FROM `U05lUM`.`appointment` WHERE (`appointmentId` = '"+ApptID+"')");
        }

        public void AddCustomer(Customer customer)
        {
            int CityID = random.Next(1, 5);
            string address2 = "";
            int active;
            if(customer.Active == true)
            {
                active = 1;
            }
            else
            {
                active = 0;
            }

            MySQL("INSERT INTO `U05lUM`.`address` (`addressId`, `address`,`address2`,`cityId`,`postalCode`,`phone`,`createDate`,`createdBy`,`lastUpdate`,`lastUpdateBy`) VALUES('"+customer.AddressID+"', '"+customer.Address+"', '"+address2+"'," +
                " '"+CityID+"', '"+customer.ZipCode+"', '"+customer.PhoneNumber+"', '"+customer.CreateDate.ToString("yyyy-MM-dd HH:mm:ss")+"', " +
                "'"+customer.CreatedBy+"', '"+customer.LastUpdate.ToString("yyyy-MM-dd HH:mm:ss")+"', '"+customer.LastUpdatedBy+"');");

            MySQL("INSERT INTO `U05lUM`.`customer` (`customerId`, `customerName`, `addressId`, `active`, `createDate`, `createdBy`, `lastUpdate`, `lastUpdateBy`) VALUES ('"+customer.CustomerID+"', '"+customer.CustomerName+"', '"+customer.AddressID+"', '"+active+"', '"+customer.CreateDate.ToString("yyyy-MM-dd HH:mm:ss")+"', '"+customer.CreatedBy+"', '"+customer.LastUpdate.ToString("yyyy-MM-dd HH:mm:ss")+"', '"+customer.LastUpdatedBy+"');");
        }

        public void UpdateCustomer(Customer customer)
        {
            int CityID = random.Next(1, 5);
            string address2 = "";
            int active;
            if (customer.Active == true)
            {
                active = 1;
            }
            else
            {
                active = 0;
            }

            MySQL("UPDATE `U05lUM`.`address` SET `address` = '"+customer.Address+"', `address2` = '"+address2+"', `postalCode` = '"+customer.ZipCode+"', `phone` = '"+customer.PhoneNumber+"', `lastUpdate` = '"+customer.LastUpdate.ToString("yyyy-MM-dd HH:mm:ss")+"', `lastUpdateBy` = '"+customer.LastUpdatedBy+"' WHERE (`addressId` = '"+customer.AddressID+"');");

            MySQL("UPDATE `U05lUM`.`customer` SET `customerName` = '"+customer.CustomerName+"', `addressId` = '"+customer.AddressID+"', `active` = '"+active+"', `lastUpdate` = '"+customer.LastUpdate.ToString("yyyy-MM-dd HH:mm:ss")+"', `lastUpdateBy` = '"+customer.LastUpdatedBy+"' WHERE (`customerId` = '"+customer.CustomerID+"');");
        }

        public void DeleteCustomer(string customerID, string AddressID)
        {
            MySQL("DELETE FROM `U05lUM`.`customer` WHERE (`customerId` = '" + customerID + "')");
            MySQL("DELETE FROM `U05lUM`.`address` WHERE (`addressId` = '" + AddressID + "')");
        }

        public void HandleOustideBusinessHours()
        {
            string ErrorMessage = "You have tried to schedule an appointment outside our normal business hours, our normal business hours are 7 days a week 9AM - 5PM. " +
                "Please try again.";
            MessageBox.Show(ErrorMessage, "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
        }
    }
}
