﻿namespace BOP1_Scheduling_Application
{
    partial class MainForm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.AppointmentsDataGridView = new System.Windows.Forms.DataGridView();
            this.AddApptBtn = new System.Windows.Forms.Button();
            this.Calendar = new System.Windows.Forms.MonthCalendar();
            this.DayButton = new System.Windows.Forms.RadioButton();
            this.WeekButton = new System.Windows.Forms.RadioButton();
            this.MonthButton = new System.Windows.Forms.RadioButton();
            this.CustIdComboBox = new System.Windows.Forms.ComboBox();
            this.CustomerDataGridView = new System.Windows.Forms.DataGridView();
            this.UpdateApptBtn = new System.Windows.Forms.Button();
            this.DeleteApptBtn = new System.Windows.Forms.Button();
            this.CustDeleteBtn = new System.Windows.Forms.Button();
            this.CustModBtn = new System.Windows.Forms.Button();
            this.CustAddBtn = new System.Windows.Forms.Button();
            this.ReportsBtn = new System.Windows.Forms.Button();
            this.ExitBtn = new System.Windows.Forms.Button();
            this.label1 = new System.Windows.Forms.Label();
            this.CustomerIDBtn = new System.Windows.Forms.Button();
            this.AllAppointmentsBtn = new System.Windows.Forms.Button();
            this.ClearSelectionBtn = new System.Windows.Forms.Button();
            ((System.ComponentModel.ISupportInitialize)(this.AppointmentsDataGridView)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.CustomerDataGridView)).BeginInit();
            this.SuspendLayout();
            // 
            // AppointmentsDataGridView
            // 
            this.AppointmentsDataGridView.AllowUserToAddRows = false;
            this.AppointmentsDataGridView.AllowUserToDeleteRows = false;
            this.AppointmentsDataGridView.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.Fill;
            this.AppointmentsDataGridView.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.AppointmentsDataGridView.Location = new System.Drawing.Point(256, 33);
            this.AppointmentsDataGridView.Name = "AppointmentsDataGridView";
            this.AppointmentsDataGridView.ReadOnly = true;
            this.AppointmentsDataGridView.RowHeadersVisible = false;
            this.AppointmentsDataGridView.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
            this.AppointmentsDataGridView.Size = new System.Drawing.Size(499, 319);
            this.AppointmentsDataGridView.TabIndex = 0;
            this.AppointmentsDataGridView.CellClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.AppointmentsDataGridView_CellClick);
            this.AppointmentsDataGridView.CellFormatting += new System.Windows.Forms.DataGridViewCellFormattingEventHandler(this.AppointmentsDataGridView_CellFormatting);
            // 
            // AddApptBtn
            // 
            this.AddApptBtn.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.AddApptBtn.Location = new System.Drawing.Point(256, 358);
            this.AddApptBtn.Name = "AddApptBtn";
            this.AddApptBtn.Size = new System.Drawing.Size(75, 32);
            this.AddApptBtn.TabIndex = 1;
            this.AddApptBtn.Text = "Add";
            this.AddApptBtn.UseVisualStyleBackColor = true;
            this.AddApptBtn.Click += new System.EventHandler(this.AddApptBtn_Click);
            // 
            // Calendar
            // 
            this.Calendar.Location = new System.Drawing.Point(17, 131);
            this.Calendar.Name = "Calendar";
            this.Calendar.TabIndex = 2;
            this.Calendar.DateSelected += new System.Windows.Forms.DateRangeEventHandler(this.Calendar_DateSelected);
            // 
            // DayButton
            // 
            this.DayButton.AutoSize = true;
            this.DayButton.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.DayButton.Location = new System.Drawing.Point(17, 35);
            this.DayButton.Name = "DayButton";
            this.DayButton.Size = new System.Drawing.Size(58, 24);
            this.DayButton.TabIndex = 3;
            this.DayButton.TabStop = true;
            this.DayButton.Text = "Day";
            this.DayButton.UseVisualStyleBackColor = true;
            this.DayButton.CheckedChanged += new System.EventHandler(this.DayButton_CheckedChanged);
            // 
            // WeekButton
            // 
            this.WeekButton.AutoSize = true;
            this.WeekButton.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.WeekButton.Location = new System.Drawing.Point(17, 65);
            this.WeekButton.Name = "WeekButton";
            this.WeekButton.Size = new System.Drawing.Size(72, 24);
            this.WeekButton.TabIndex = 4;
            this.WeekButton.TabStop = true;
            this.WeekButton.Text = "Week";
            this.WeekButton.UseVisualStyleBackColor = true;
            this.WeekButton.CheckedChanged += new System.EventHandler(this.WeekButton_CheckedChanged);
            // 
            // MonthButton
            // 
            this.MonthButton.AutoSize = true;
            this.MonthButton.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.MonthButton.Location = new System.Drawing.Point(17, 95);
            this.MonthButton.Name = "MonthButton";
            this.MonthButton.Size = new System.Drawing.Size(77, 24);
            this.MonthButton.TabIndex = 5;
            this.MonthButton.TabStop = true;
            this.MonthButton.Text = "Month";
            this.MonthButton.UseVisualStyleBackColor = true;
            this.MonthButton.CheckedChanged += new System.EventHandler(this.MonthButton_CheckedChanged);
            // 
            // CustIdComboBox
            // 
            this.CustIdComboBox.FormattingEnabled = true;
            this.CustIdComboBox.Location = new System.Drawing.Point(93, 305);
            this.CustIdComboBox.Name = "CustIdComboBox";
            this.CustIdComboBox.Size = new System.Drawing.Size(151, 21);
            this.CustIdComboBox.TabIndex = 6;
            // 
            // CustomerDataGridView
            // 
            this.CustomerDataGridView.AllowUserToAddRows = false;
            this.CustomerDataGridView.AllowUserToDeleteRows = false;
            this.CustomerDataGridView.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.Fill;
            this.CustomerDataGridView.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.CustomerDataGridView.Location = new System.Drawing.Point(782, 33);
            this.CustomerDataGridView.Name = "CustomerDataGridView";
            this.CustomerDataGridView.ReadOnly = true;
            this.CustomerDataGridView.RowHeadersVisible = false;
            this.CustomerDataGridView.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
            this.CustomerDataGridView.Size = new System.Drawing.Size(499, 319);
            this.CustomerDataGridView.TabIndex = 7;
            this.CustomerDataGridView.CellClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.CustomerDataGridView_CellClick);
            // 
            // UpdateApptBtn
            // 
            this.UpdateApptBtn.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.UpdateApptBtn.Location = new System.Drawing.Point(337, 358);
            this.UpdateApptBtn.Name = "UpdateApptBtn";
            this.UpdateApptBtn.Size = new System.Drawing.Size(75, 32);
            this.UpdateApptBtn.TabIndex = 8;
            this.UpdateApptBtn.Text = "Update";
            this.UpdateApptBtn.UseVisualStyleBackColor = true;
            this.UpdateApptBtn.Click += new System.EventHandler(this.UpdateApptBtn_Click);
            // 
            // DeleteApptBtn
            // 
            this.DeleteApptBtn.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.DeleteApptBtn.Location = new System.Drawing.Point(418, 358);
            this.DeleteApptBtn.Name = "DeleteApptBtn";
            this.DeleteApptBtn.Size = new System.Drawing.Size(75, 32);
            this.DeleteApptBtn.TabIndex = 9;
            this.DeleteApptBtn.Text = "Delete";
            this.DeleteApptBtn.UseVisualStyleBackColor = true;
            this.DeleteApptBtn.Click += new System.EventHandler(this.DeleteApptBtn_Click);
            // 
            // CustDeleteBtn
            // 
            this.CustDeleteBtn.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.CustDeleteBtn.Location = new System.Drawing.Point(944, 360);
            this.CustDeleteBtn.Name = "CustDeleteBtn";
            this.CustDeleteBtn.Size = new System.Drawing.Size(75, 32);
            this.CustDeleteBtn.TabIndex = 12;
            this.CustDeleteBtn.Text = "Delete";
            this.CustDeleteBtn.UseVisualStyleBackColor = true;
            this.CustDeleteBtn.Click += new System.EventHandler(this.CustDeleteBtn_Click);
            // 
            // CustModBtn
            // 
            this.CustModBtn.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.CustModBtn.Location = new System.Drawing.Point(863, 360);
            this.CustModBtn.Name = "CustModBtn";
            this.CustModBtn.Size = new System.Drawing.Size(75, 32);
            this.CustModBtn.TabIndex = 11;
            this.CustModBtn.Text = "Update";
            this.CustModBtn.UseVisualStyleBackColor = true;
            this.CustModBtn.Click += new System.EventHandler(this.CustModBtn_Click);
            // 
            // CustAddBtn
            // 
            this.CustAddBtn.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.CustAddBtn.Location = new System.Drawing.Point(782, 360);
            this.CustAddBtn.Name = "CustAddBtn";
            this.CustAddBtn.Size = new System.Drawing.Size(75, 32);
            this.CustAddBtn.TabIndex = 10;
            this.CustAddBtn.Text = "Add";
            this.CustAddBtn.UseVisualStyleBackColor = true;
            this.CustAddBtn.Click += new System.EventHandler(this.CustAddBtn_Click);
            // 
            // ReportsBtn
            // 
            this.ReportsBtn.Location = new System.Drawing.Point(17, 469);
            this.ReportsBtn.Name = "ReportsBtn";
            this.ReportsBtn.Size = new System.Drawing.Size(95, 32);
            this.ReportsBtn.TabIndex = 13;
            this.ReportsBtn.Text = "Reports";
            this.ReportsBtn.UseVisualStyleBackColor = true;
            this.ReportsBtn.Click += new System.EventHandler(this.ReportsBtn_Click);
            // 
            // ExitBtn
            // 
            this.ExitBtn.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.ExitBtn.Location = new System.Drawing.Point(1207, 472);
            this.ExitBtn.Name = "ExitBtn";
            this.ExitBtn.Size = new System.Drawing.Size(75, 29);
            this.ExitBtn.TabIndex = 14;
            this.ExitBtn.Text = "Exit";
            this.ExitBtn.UseVisualStyleBackColor = true;
            this.ExitBtn.Click += new System.EventHandler(this.ExitBtn_Click);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(17, 308);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(71, 13);
            this.label1.TabIndex = 15;
            this.label1.Text = "Customer ID: ";
            // 
            // CustomerIDBtn
            // 
            this.CustomerIDBtn.Location = new System.Drawing.Point(17, 332);
            this.CustomerIDBtn.Name = "CustomerIDBtn";
            this.CustomerIDBtn.Size = new System.Drawing.Size(107, 34);
            this.CustomerIDBtn.TabIndex = 16;
            this.CustomerIDBtn.Text = "Narrow  Appointments";
            this.CustomerIDBtn.UseVisualStyleBackColor = true;
            this.CustomerIDBtn.Click += new System.EventHandler(this.CustomerIDBtn_Click);
            // 
            // AllAppointmentsBtn
            // 
            this.AllAppointmentsBtn.Location = new System.Drawing.Point(17, 382);
            this.AllAppointmentsBtn.Name = "AllAppointmentsBtn";
            this.AllAppointmentsBtn.Size = new System.Drawing.Size(107, 34);
            this.AllAppointmentsBtn.TabIndex = 17;
            this.AllAppointmentsBtn.Text = "Show All  Appt.";
            this.AllAppointmentsBtn.UseVisualStyleBackColor = true;
            this.AllAppointmentsBtn.Click += new System.EventHandler(this.AllAppointmentsBtn_Click);
            // 
            // ClearSelectionBtn
            // 
            this.ClearSelectionBtn.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.ClearSelectionBtn.Location = new System.Drawing.Point(118, 33);
            this.ClearSelectionBtn.Name = "ClearSelectionBtn";
            this.ClearSelectionBtn.Size = new System.Drawing.Size(132, 23);
            this.ClearSelectionBtn.TabIndex = 18;
            this.ClearSelectionBtn.Text = "Clear Selection";
            this.ClearSelectionBtn.UseVisualStyleBackColor = true;
            this.ClearSelectionBtn.Click += new System.EventHandler(this.ClearSelectionBtn_Click);
            // 
            // MainForm
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1294, 513);
            this.Controls.Add(this.ClearSelectionBtn);
            this.Controls.Add(this.AllAppointmentsBtn);
            this.Controls.Add(this.CustomerIDBtn);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.ExitBtn);
            this.Controls.Add(this.ReportsBtn);
            this.Controls.Add(this.CustDeleteBtn);
            this.Controls.Add(this.CustModBtn);
            this.Controls.Add(this.CustAddBtn);
            this.Controls.Add(this.DeleteApptBtn);
            this.Controls.Add(this.UpdateApptBtn);
            this.Controls.Add(this.CustomerDataGridView);
            this.Controls.Add(this.CustIdComboBox);
            this.Controls.Add(this.MonthButton);
            this.Controls.Add(this.WeekButton);
            this.Controls.Add(this.DayButton);
            this.Controls.Add(this.Calendar);
            this.Controls.Add(this.AddApptBtn);
            this.Controls.Add(this.AppointmentsDataGridView);
            this.Name = "MainForm";
            this.Text = "MainForm";
            this.Load += new System.EventHandler(this.MainForm_Load);
            ((System.ComponentModel.ISupportInitialize)(this.AppointmentsDataGridView)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.CustomerDataGridView)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion
        private System.Windows.Forms.Button AddApptBtn;
        private System.Windows.Forms.MonthCalendar Calendar;
        private System.Windows.Forms.RadioButton DayButton;
        private System.Windows.Forms.RadioButton WeekButton;
        private System.Windows.Forms.RadioButton MonthButton;
        private System.Windows.Forms.ComboBox CustIdComboBox;
        private System.Windows.Forms.Button UpdateApptBtn;
        private System.Windows.Forms.Button DeleteApptBtn;
        private System.Windows.Forms.Button CustDeleteBtn;
        private System.Windows.Forms.Button CustModBtn;
        private System.Windows.Forms.Button CustAddBtn;
        private System.Windows.Forms.Button ReportsBtn;
        private System.Windows.Forms.Button ExitBtn;
        public System.Windows.Forms.DataGridView AppointmentsDataGridView;
        public System.Windows.Forms.DataGridView CustomerDataGridView;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Button CustomerIDBtn;
        private System.Windows.Forms.Button AllAppointmentsBtn;
        private System.Windows.Forms.Button ClearSelectionBtn;
    }
}