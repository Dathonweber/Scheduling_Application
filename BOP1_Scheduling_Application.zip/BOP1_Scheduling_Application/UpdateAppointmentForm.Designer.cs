﻿namespace BOP1_Scheduling_Application
{
    partial class UpdateAppointmentForm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.EndDateLbl = new System.Windows.Forms.Label();
            this.strtdatelbl = new System.Windows.Forms.Label();
            this.TypeLbl = new System.Windows.Forms.Label();
            this.CustIDLbl = new System.Windows.Forms.Label();
            this.AptIDLbl = new System.Windows.Forms.Label();
            this.UpdateAppointmentBtn = new System.Windows.Forms.Button();
            this.CancelBtn = new System.Windows.Forms.Button();
            this.EndDateDateTime = new System.Windows.Forms.DateTimePicker();
            this.StartDateDateTime = new System.Windows.Forms.DateTimePicker();
            this.AppointmentTypeTxtBox = new System.Windows.Forms.TextBox();
            this.CustomerIDTxtBox = new System.Windows.Forms.TextBox();
            this.AppointmentIDTxtBox = new System.Windows.Forms.TextBox();
            this.SuspendLayout();
            // 
            // EndDateLbl
            // 
            this.EndDateLbl.AutoSize = true;
            this.EndDateLbl.Location = new System.Drawing.Point(91, 275);
            this.EndDateLbl.Name = "EndDateLbl";
            this.EndDateLbl.Size = new System.Drawing.Size(52, 13);
            this.EndDateLbl.TabIndex = 26;
            this.EndDateLbl.Text = "End Date";
            // 
            // strtdatelbl
            // 
            this.strtdatelbl.AutoSize = true;
            this.strtdatelbl.Location = new System.Drawing.Point(87, 220);
            this.strtdatelbl.Name = "strtdatelbl";
            this.strtdatelbl.Size = new System.Drawing.Size(55, 13);
            this.strtdatelbl.TabIndex = 25;
            this.strtdatelbl.Text = "Start Date";
            // 
            // TypeLbl
            // 
            this.TypeLbl.AutoSize = true;
            this.TypeLbl.Location = new System.Drawing.Point(49, 165);
            this.TypeLbl.Name = "TypeLbl";
            this.TypeLbl.Size = new System.Drawing.Size(93, 13);
            this.TypeLbl.TabIndex = 24;
            this.TypeLbl.Text = "Appointment Type";
            // 
            // CustIDLbl
            // 
            this.CustIDLbl.AutoSize = true;
            this.CustIDLbl.Location = new System.Drawing.Point(80, 110);
            this.CustIDLbl.Name = "CustIDLbl";
            this.CustIDLbl.Size = new System.Drawing.Size(62, 13);
            this.CustIDLbl.TabIndex = 22;
            this.CustIDLbl.Text = "CustomerID";
            // 
            // AptIDLbl
            // 
            this.AptIDLbl.AutoSize = true;
            this.AptIDLbl.Location = new System.Drawing.Point(62, 55);
            this.AptIDLbl.Name = "AptIDLbl";
            this.AptIDLbl.Size = new System.Drawing.Size(80, 13);
            this.AptIDLbl.TabIndex = 21;
            this.AptIDLbl.Text = "Appointment ID";
            // 
            // UpdateAppointmentBtn
            // 
            this.UpdateAppointmentBtn.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.UpdateAppointmentBtn.Location = new System.Drawing.Point(186, 347);
            this.UpdateAppointmentBtn.Name = "UpdateAppointmentBtn";
            this.UpdateAppointmentBtn.Size = new System.Drawing.Size(91, 34);
            this.UpdateAppointmentBtn.TabIndex = 20;
            this.UpdateAppointmentBtn.Text = "Update";
            this.UpdateAppointmentBtn.UseVisualStyleBackColor = true;
            this.UpdateAppointmentBtn.Click += new System.EventHandler(this.UpdateAppointmentBtn_Click);
            // 
            // CancelBtn
            // 
            this.CancelBtn.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.CancelBtn.Location = new System.Drawing.Point(283, 347);
            this.CancelBtn.Name = "CancelBtn";
            this.CancelBtn.Size = new System.Drawing.Size(91, 34);
            this.CancelBtn.TabIndex = 19;
            this.CancelBtn.Text = "Cancel";
            this.CancelBtn.UseVisualStyleBackColor = true;
            this.CancelBtn.Click += new System.EventHandler(this.CancelBtn_Click);
            // 
            // EndDateDateTime
            // 
            this.EndDateDateTime.Format = System.Windows.Forms.DateTimePickerFormat.Time;
            this.EndDateDateTime.Location = new System.Drawing.Point(149, 272);
            this.EndDateDateTime.Name = "EndDateDateTime";
            this.EndDateDateTime.Size = new System.Drawing.Size(158, 20);
            this.EndDateDateTime.TabIndex = 16;
            // 
            // StartDateDateTime
            // 
            this.StartDateDateTime.Format = System.Windows.Forms.DateTimePickerFormat.Time;
            this.StartDateDateTime.Location = new System.Drawing.Point(149, 217);
            this.StartDateDateTime.Name = "StartDateDateTime";
            this.StartDateDateTime.Size = new System.Drawing.Size(158, 20);
            this.StartDateDateTime.TabIndex = 15;
            // 
            // AppointmentTypeTxtBox
            // 
            this.AppointmentTypeTxtBox.Location = new System.Drawing.Point(149, 162);
            this.AppointmentTypeTxtBox.Name = "AppointmentTypeTxtBox";
            this.AppointmentTypeTxtBox.Size = new System.Drawing.Size(158, 20);
            this.AppointmentTypeTxtBox.TabIndex = 11;
            // 
            // CustomerIDTxtBox
            // 
            this.CustomerIDTxtBox.Location = new System.Drawing.Point(149, 107);
            this.CustomerIDTxtBox.Name = "CustomerIDTxtBox";
            this.CustomerIDTxtBox.Size = new System.Drawing.Size(158, 20);
            this.CustomerIDTxtBox.TabIndex = 1;
            // 
            // AppointmentIDTxtBox
            // 
            this.AppointmentIDTxtBox.Enabled = false;
            this.AppointmentIDTxtBox.Location = new System.Drawing.Point(149, 52);
            this.AppointmentIDTxtBox.Name = "AppointmentIDTxtBox";
            this.AppointmentIDTxtBox.Size = new System.Drawing.Size(158, 20);
            this.AppointmentIDTxtBox.TabIndex = 0;
            // 
            // UpdateAppointmentForm
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(386, 393);
            this.Controls.Add(this.EndDateLbl);
            this.Controls.Add(this.strtdatelbl);
            this.Controls.Add(this.TypeLbl);
            this.Controls.Add(this.CustIDLbl);
            this.Controls.Add(this.AptIDLbl);
            this.Controls.Add(this.UpdateAppointmentBtn);
            this.Controls.Add(this.CancelBtn);
            this.Controls.Add(this.EndDateDateTime);
            this.Controls.Add(this.StartDateDateTime);
            this.Controls.Add(this.AppointmentTypeTxtBox);
            this.Controls.Add(this.CustomerIDTxtBox);
            this.Controls.Add(this.AppointmentIDTxtBox);
            this.Name = "UpdateAppointmentForm";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "UpdateAppointmentForm";
            this.Load += new System.EventHandler(this.UpdateAppointmentForm_Load);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion
        private System.Windows.Forms.Label EndDateLbl;
        private System.Windows.Forms.Label strtdatelbl;
        private System.Windows.Forms.Label TypeLbl;
        private System.Windows.Forms.Label CustIDLbl;
        private System.Windows.Forms.Label AptIDLbl;
        private System.Windows.Forms.Button UpdateAppointmentBtn;
        private System.Windows.Forms.Button CancelBtn;
        private System.Windows.Forms.DateTimePicker EndDateDateTime;
        private System.Windows.Forms.DateTimePicker StartDateDateTime;
        private System.Windows.Forms.TextBox AppointmentTypeTxtBox;
        private System.Windows.Forms.TextBox CustomerIDTxtBox;
        private System.Windows.Forms.TextBox AppointmentIDTxtBox;
    }
}