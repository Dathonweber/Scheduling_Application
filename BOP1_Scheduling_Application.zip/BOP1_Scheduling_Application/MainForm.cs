﻿using MySql.Data.MySqlClient;
using System;
using System.Collections.Generic;
using System.Configuration;
using System.Data;
using System.Drawing;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace BOP1_Scheduling_Application
{
    public partial class MainForm : Form
    {
        static string myConnectionString = "server=3.227.166.251;database=U05lUM;user=U05lUM;pwd=53688540322";
        MySqlConnection Conn = new MySqlConnection(myConnectionString);
        MySqlDataReader mdr;
        List<Appointment> CustomerIDAppointments = new List<Appointment>();

        public DataTable AGV = new DataTable();
        DataTable CustomerGridView = new DataTable();
        DateTime currentDate;
        Func<DateTime, String> ConvertDateTime = dt => dt.ToString("yyyy-MM-dd HH:mm:ss");

        // Lambda Expression #2 this lambda expression is created so I can convert all DateTimes into the MySQL DateFormat using just the Action instead of having to type it out every time.


        public MainForm()
        {
            InitializeComponent();
            currentDate = DateTime.SpecifyKind(DateTime.Now, DateTimeKind.Local);
            Calendar.AddBoldedDate(currentDate);
            DayButton.Checked = false;
            CustIdComboBox.DataSource = SQL.CustomerIDList;
            CustIdComboBox.SelectedItem = null;


            AppointmentsDataGridView.DataSource = AGV;
            AppointmentsDataGridView.DefaultCellStyle.SelectionBackColor = AppointmentsDataGridView.DefaultCellStyle.BackColor;
            AppointmentsDataGridView.DefaultCellStyle.SelectionForeColor = AppointmentsDataGridView.DefaultCellStyle.ForeColor;
            AppointmentsDataGridView.ColumnHeadersDefaultCellStyle.Font = new Font("Microsoft Sans Serif", 10, FontStyle.Regular);
            AppointmentsDataGridView.DefaultCellStyle.Font = new Font("Microsoft Sans Serif", 10, FontStyle.Regular);
            AppointmentsDataGridView.RowHeadersVisible = false;
            AppointmentsDataGridView.ClearSelection();
            AppointmentsDataGridView.ColumnHeadersDefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleCenter;

            CustomerDataGridView.DataSource = CustomerGridView;
            CustomerDataGridView.DefaultCellStyle.SelectionBackColor = CustomerDataGridView.DefaultCellStyle.BackColor;
            CustomerDataGridView.DefaultCellStyle.SelectionForeColor = CustomerDataGridView.DefaultCellStyle.ForeColor;
            CustomerDataGridView.ColumnHeadersDefaultCellStyle.Font = new Font("Microsoft Sans Serif", 10, FontStyle.Regular);
            CustomerDataGridView.DefaultCellStyle.Font = new Font("Microsoft Sans Serif", 10, FontStyle.Regular);
            CustomerDataGridView.RowHeadersVisible = false;
            CustomerDataGridView.ClearSelection();
            CustomerDataGridView.ColumnHeadersDefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleCenter;

        }

        public void GetAppointmentData(string s)
        {
            MySqlCommand cmd = new MySqlCommand(s, Conn);
            Conn.Open();
            MySqlDataAdapter adapter = new MySqlDataAdapter();
            adapter.SelectCommand = cmd;
            adapter.Fill(AGV);
            Conn.Close();
        }

        public void GetCustomerData(string s)
        {
            MySqlCommand cmd = new MySqlCommand(s, Conn);
            Conn.Open();
            MySqlDataAdapter adapter = new MySqlDataAdapter();
            adapter.SelectCommand = cmd;
            adapter.Fill(CustomerGridView);
            Conn.Close();
        }

        private void MainForm_Load(object sender, EventArgs e)
        {

            GetAppointmentData("Select * FROM appointment;");
            GetCustomerData("Select * from customer;");



            AppointmentsDataGridView.Columns["title"].Visible = false;
            AppointmentsDataGridView.Columns["description"].Visible = false;
            AppointmentsDataGridView.Columns["location"].Visible = false;
            AppointmentsDataGridView.Columns["contact"].Visible = false;
            AppointmentsDataGridView.Columns["url"].Visible = false;
            AppointmentsDataGridView.Columns["userId"].Visible = false;
            AppointmentsDataGridView.Columns["createDate"].Visible = false;
            AppointmentsDataGridView.Columns["createdBy"].Visible = false;
            AppointmentsDataGridView.Columns["lastUpdate"].Visible = false;
            AppointmentsDataGridView.Columns["lastUpdateBy"].Visible = false;

            CustomerDataGridView.Columns["createDate"].Visible = false;
            CustomerDataGridView.Columns["createdBy"].Visible = false;
            CustomerDataGridView.Columns["lastUpdate"].Visible = false;
            CustomerDataGridView.Columns["lastUpdateBy"].Visible = false;
            CustomerDataGridView.Columns["active"].Visible = false;

            Task.Delay(500).ContinueWith(t => Reminder());

        }

        private void ExitBtn_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }

        private void AddApptBtn_Click(object sender, EventArgs e)
        {
            AddAppointmentForm addAppointmentForm = new AddAppointmentForm();
            this.Hide();
            addAppointmentForm.Show();

        }

        private void UpdateApptBtn_Click(object sender, EventArgs e)
        {
            if (SQL.AppointmentIndex > 0)
            {
                UpdateAppointmentForm updateAppointmentForm = new UpdateAppointmentForm();
                this.Hide();
                updateAppointmentForm.Show();
            }
            else
            {
                MessageBox.Show("Please Select Something To Modify");
            }
        }

        private void CustAddBtn_Click(object sender, EventArgs e)
        {
            AddCustomerForm addCustomerForm = new AddCustomerForm();
            this.Hide();
            addCustomerForm.Show();
        }

        private void CustModBtn_Click(object sender, EventArgs e)
        {
            if (SQL.CustomerIndex > 0)
            {

                UpdateCustomerForm updateCustomerForm = new UpdateCustomerForm();
                this.Hide();
                updateCustomerForm.Show();
            }
            else
            {
                MessageBox.Show("Please Select Something To Modify");
            }
        }

        private void DaySelect()
        {
            Calendar.RemoveAllBoldedDates();
            Calendar.AddBoldedDate(currentDate);
            Calendar.UpdateBoldedDates();
            AGV.Clear();
            string queryDate = ConvertDateTime(currentDate);
            GetAppointmentData("SELECT * from appointment where date(start) = '" + queryDate + "';");
            AppointmentsDataGridView.DataSource = AGV;

        }

        private void WeekSelect()
        {
            Calendar.RemoveAllBoldedDates();
            AGV.Clear();
            int DayOfWeek = (int)currentDate.DayOfWeek;
            string startDate = currentDate.AddDays(-DayOfWeek).ToString();
            DateTime tempDate = Convert.ToDateTime(startDate);
            for (int i = 0; i < 7; i++)
            {
                Calendar.AddBoldedDate(tempDate.AddDays(i));
            }
            Calendar.UpdateBoldedDates();
            DateTime TemporaryEndDate = currentDate.AddDays(7 - DayOfWeek);
            string EndDate = ConvertDateTime(TemporaryEndDate);
            string StartDate = ConvertDateTime(tempDate);
            GetAppointmentData("SELECT * from appointment where date(start) between '" + StartDate + "' and '" + EndDate + "';");
            AppointmentsDataGridView.DataSource = AGV;
        }

        private void MonthSelect()
        {
            Calendar.RemoveAllBoldedDates();
            AGV.Clear();
            int month = currentDate.Month;
            int year = currentDate.Year;
            int day = 0;
            string QueryStartDate = year.ToString() + "-" + month.ToString() + "-01";
            string startDate = month.ToString() + "/01/" + year.ToString();
            DateTime tempDate = Convert.ToDateTime(startDate);
            switch (month)
            {
                case 1:
                case 3:
                case 5:
                case 7:
                case 8:
                case 10:
                    day = 31;
                    break;
                case 4:
                case 6:
                case 9:
                case 11:
                    day = 30;
                    break;
                default:
                    day = 29;
                    break;
            }
            for (int i = 0; i < day; i++)
            {
                Calendar.AddBoldedDate(tempDate.AddDays(i));
            }
            Calendar.UpdateBoldedDates();
            DateTime endDate = Convert.ToDateTime(month.ToString() + "/" + day.ToString() + "/" + year.ToString());
            string EndDate = ConvertDateTime(endDate);
            string StartDate = ConvertDateTime(tempDate);
            GetAppointmentData("SELECT * from appointment where date(start) between '" + StartDate + "' and '" + EndDate + "';");
            AppointmentsDataGridView.DataSource = AGV;
        }

        private void DayButton_CheckedChanged(object sender, EventArgs e)
        {
            DaySelect();
        }

        private void WeekButton_CheckedChanged(object sender, EventArgs e)
        {
            WeekSelect();
        }

        private void MonthButton_CheckedChanged(object sender, EventArgs e)
        {
            MonthSelect();
        }

        private void Calendar_DateSelected(object sender, DateRangeEventArgs e)
        {
            currentDate = e.Start;
            if (MonthButton.Checked)
            {
                MonthSelect();
            }
            else
            {
                if (WeekButton.Checked)
                {
                    WeekSelect();
                }
                else
                {
                    DaySelect();
                }
            }
        }

        private void AppointmentsDataGridView_CellClick(object sender, DataGridViewCellEventArgs e)
        {
            SQL.AppointmentIndex = e.RowIndex + 1;
            AppointmentsDataGridView.DefaultCellStyle.SelectionBackColor = Color.Yellow;
        }

        private void DeleteApptBtn_Click(object sender, EventArgs e)
        {
            SQL MSQL = new SQL();
            if (SQL.AppointmentIndex > 0)
            {
                if (MessageBox.Show("Are you sure you want to delete this appointment?", "Delete Appointment?", MessageBoxButtons.YesNo, MessageBoxIcon.Question) == DialogResult.Yes)
                {
                    MSQL.DeleteAppointment(SQL.AppointmentIndex.ToString());
                    AGV.Rows.RemoveAt(SQL.AppointmentIndex - 1);
                }

            }
            else
            {
                MessageBox.Show("Please Select Something To Delete");
            }
        }

        private void CustomerDataGridView_CellClick(object sender, DataGridViewCellEventArgs e)
        {
            SQL.CustomerIndex = e.RowIndex + 1;
            string query = "Select addressId from customer WHERE customerId = '" + SQL.CustomerIndex + "';";
            Conn.Open();
            MySqlCommand command = new MySqlCommand(query, Conn);
            mdr = command.ExecuteReader();
            if (mdr.Read())
            {
                SQL.AddressIndex = mdr.GetInt32("addressId");
            }
            Conn.Close();
            CustomerDataGridView.DefaultCellStyle.SelectionBackColor = Color.Yellow;
        }

        public void Reminder()
        {
            DateTime Start = DateTime.Now;
            DateTime End = DateTime.Now.AddMinutes(15);
            Conn.Open();
            string Query = "Select * FROM appointment Where start between '" + Start.ToString("yyyy-MM-dd HH:mm:ss") + "' and '" + End.ToString("yyyy-MM-dd HH:mm:ss") + "' LIMIT 1";
            MySqlCommand command = new MySqlCommand(Query, Conn);
            MySqlDataReader mdr;
            using (mdr = command.ExecuteReader())
            {
                while (mdr.Read())
                {
                    int id = mdr.GetInt32("appointmentId");
                    DateTime date = mdr.GetDateTime("start");

                    Action ApptDisplay = () => MessageBox.Show($"Appointment ID: {id.ToString()} has an Appointment at {date.ToString("HH:mm:ss")}");
                    // Lambda Expression #1 - Creating this Action To be able to be called later inside of the Method Without the need to Type of the Entire MessageBox.Show() Statement.
                    ApptDisplay();
                }
            }
            Conn.Close();
        }

        private void CustDeleteBtn_Click(object sender, EventArgs e)
        {
            SQL sql = new SQL();
            if (SQL.CustomerIndex > 0)
            {
                if (MessageBox.Show("Are you sure you want to Delete This Customer?", "Delete Customer?", MessageBoxButtons.YesNo, MessageBoxIcon.Question) == DialogResult.Yes)
                {
                    sql.DeleteCustomer(SQL.CustomerIndex.ToString(), SQL.AddressIndex.ToString());
                    CustomerGridView.Rows.RemoveAt(SQL.CustomerIndex - 1);
                }
            }
            else
            {
                MessageBox.Show("Please Select Something To Delete");
            }
        }

        private void ReportsBtn_Click(object sender, EventArgs e)
        {
            ReportsForm reports = new ReportsForm();
            reports.Show();
            this.Hide();
        }

        private void CustomerIDBtn_Click(object sender, EventArgs e)
        {
            Conn.Open();
            string Query = "SELECT * FROM appointment WHERE customerId = '" + CustIdComboBox.SelectedItem.ToString() + "'";
            MySqlCommand command = new MySqlCommand(Query, Conn);
            using (mdr = command.ExecuteReader())
            {
                while (mdr.Read())
                {
                    int appointmentId = mdr.GetInt32("appointmentId");
                    int customerId = mdr.GetInt32("customerId");
                    int userId = mdr.GetInt32("userId");
                    string title = mdr.GetString("title");
                    string description = mdr.GetString("description");
                    string location = mdr.GetString("location");
                    string contact = mdr.GetString("contact");
                    string type = mdr.GetString("type");
                    string url = mdr.GetString("url");
                    DateTime start = mdr.GetDateTime("start");
                    DateTime end = mdr.GetDateTime("end");
                    DateTime createDate = mdr.GetDateTime("createDate");
                    string createdBy = mdr.GetString("createdBy");
                    DateTime lastUpdate = mdr.GetDateTime("lastUpdate");
                    string lastUpdateBy = mdr.GetString("lastUpdateBy");

                    CustomerIDAppointments.Add(new Appointment(appointmentId, customerId, userId, title, description, location, contact, type, url, start, end, createDate, createdBy, lastUpdate, lastUpdateBy));
                }
            }
            Conn.Close();

            AppointmentsDataGridView.DataSource = CustomerIDAppointments;
            AppointmentsDataGridView.Columns["title"].Visible = false;
            AppointmentsDataGridView.Columns["description"].Visible = false;
            AppointmentsDataGridView.Columns["location"].Visible = false;
            AppointmentsDataGridView.Columns["contact"].Visible = false;
            AppointmentsDataGridView.Columns["url"].Visible = false;
            AppointmentsDataGridView.Columns["userId"].Visible = false;
            AppointmentsDataGridView.Columns["createDate"].Visible = false;
            AppointmentsDataGridView.Columns["createdBy"].Visible = false;
            AppointmentsDataGridView.Columns["lastUpdate"].Visible = false;
            AppointmentsDataGridView.Columns["lastUpdate"].Visible = false;
            AppointmentsDataGridView.Columns["LastUpdatedBy"].Visible = false;

        }

        private void AllAppointmentsBtn_Click(object sender, EventArgs e)
        {
            CustomerIDAppointments.Clear();
            AGV.Clear();
            GetAppointmentData("Select * FROM appointment;");
            AppointmentsDataGridView.DataSource = AGV;
            AppointmentsDataGridView.Columns["lastUpdateBy"].Visible = false;
        }

        private void ClearSelectionBtn_Click(object sender, EventArgs e)
        {
            WeekButton.Checked = false;
            DayButton.Checked = false;
            MonthButton.Checked = false;
            AGV.Clear();
            GetAppointmentData("Select * FROM appointment;");
        }

        private void AppointmentsDataGridView_CellFormatting(object sender, DataGridViewCellFormattingEventArgs e)
        {
            if (e.Value is DateTime)
            {

                String ID = TimeZoneInfo.Local.Id;
                if (ID == "Central Standard Time")
                {
                    e.Value = ((DateTime)e.Value).ToLocalTime().AddHours(5);
                }
                else
                {
                    if (ID == "Eastern Standard Time")
                    {
                        e.Value = ((DateTime)e.Value).ToLocalTime().AddHours(4);
                    }
                    else
                    {
                        if (ID == "Mountain Standard Time")
                        {
                            e.Value = ((DateTime)e.Value).ToLocalTime().AddHours(6);
                        }
                        else
                        {
                            if (ID == "Pacific Standard Time")
                            {
                                e.Value = ((DateTime)e.Value).ToLocalTime().AddHours(7);
                            }
                        }
                    }
                }
            }
                            
        }
    }
}
