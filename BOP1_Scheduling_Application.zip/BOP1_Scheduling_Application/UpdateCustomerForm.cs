﻿using MySql.Data.MySqlClient;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Text.RegularExpressions;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace BOP1_Scheduling_Application
{
    public partial class UpdateCustomerForm : Form
    {
        MySqlConnection Conn = new MySqlConnection(SQL.myConnectionString);
        MySqlDataReader mdr;
        SQL sql = new SQL();
        MainForm MainForm = new MainForm();
        public UpdateCustomerForm()
        {
            InitializeComponent();
            string query = "Select * from customer WHERE customerId = '" + SQL.CustomerIndex + "';";
            Conn.Open();
            MySqlCommand command = new MySqlCommand(query, Conn);
            mdr = command.ExecuteReader();
            if (mdr.Read())
            {
                CustomerIDTxtBox.Text = mdr.GetInt32("customerId").ToString();
                CustomerNameTxtBox.Text = mdr.GetString("customerName");
                int active = mdr.GetInt32("active");
                AddressIDTxtBox.Text = mdr.GetInt32("addressId").ToString();
                if (active > 0)
                {
                    YesCheckBox.Checked = true;
                }
                else
                {
                    NoCheckBox.Checked = true;
                }
            }

            Conn.Close();

            string Query = "Select * from address WHERE addressId = '" + Convert.ToInt32(AddressIDTxtBox.Text) +"';";
            Conn.Open(); 
            MySqlCommand Command = new MySqlCommand(Query, Conn);
            MySqlDataReader mySqlDataReader = Command.ExecuteReader();
            if (mySqlDataReader.Read())
            {
                AddressTxtBox.Text = mySqlDataReader.GetString("address");
                ZipCodeTxtBox.Text = mySqlDataReader.GetString("postalCode");
                PhoneNumberTxtBox.Text = mySqlDataReader.GetString("phone");
            }
        }

        private Boolean CustomerCorrectInfo()
        {
            string ZipcodeFormat = @"^\d{5}(?:[-\s]\d{4})?$";
            Regex ZipCode = new Regex(ZipcodeFormat);
            string phoneFormat = @"\(?\d{3}\)?-? *\d{3}-? *-?\d{4}";
            Regex phone = new Regex(phoneFormat);
            if (string.IsNullOrWhiteSpace(CustomerNameTxtBox.Text))
            {
                return false;
            }
            if (string.IsNullOrWhiteSpace(CustomerIDTxtBox.Text))
            {
                return false;
            }
            else if (string.IsNullOrWhiteSpace(AddressTxtBox.Text))
            {
                return false;
            }
            else if (YesCheckBox.Checked == false && NoCheckBox.Checked == false)
            {
                return false;
            }
            else if (ZipCode.IsMatch(ZipCodeTxtBox.Text) == false)
            {
                return false;
            }
            else if (phone.IsMatch(PhoneNumberTxtBox.Text) == false)
            {
                return false;
            }
            return true;
        }
        private void ExitBtn_Click(object sender, EventArgs e)
        {
            MainForm mf = new MainForm();
            mf.Show();
            this.Hide();
        }

        private void UpdateCustomerBtn_Click(object sender, EventArgs e)
        {
            if (CustomerCorrectInfo() == false)
            {
                MessageBox.Show("There was a problem trying to Update this customer in the system please try again", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
            else
            {
                try
                {
                    int customerId = Convert.ToInt32(CustomerIDTxtBox.Text);
                    string customername = CustomerNameTxtBox.Text;
                    int AddressID = Convert.ToInt32(AddressIDTxtBox.Text);
                    bool active;
                    if (YesCheckBox.Checked == true)
                    {
                        active = true;
                    }
                    else
                    {
                        active = false;
                    }
                    string address = AddressTxtBox.Text;
                    string zipcode = ZipCodeTxtBox.Text;
                    string phone = PhoneNumberTxtBox.Text;
                    DateTime lastupdate = DateTime.Now;
                    string lastUpdateBy = "test";

                    SQL sql = new SQL();
                    sql.UpdateCustomer(new Customer(customerId, AddressID, customername, active, address, zipcode, phone, lastupdate, lastUpdateBy));
                }
                catch (FormatException F)
                {
                    MessageBox.Show(F.Message);
                }

                MainForm.Show();
                this.Hide();
            }
        }

        private void YesCheckBox_CheckedChanged(object sender, EventArgs e)
        {
            if (NoCheckBox.Checked == true)
            { 
            NoCheckBox.Checked = false;
            }
         
        }

        private void NoCheckBox_CheckedChanged(object sender, EventArgs e)
        {
            if (YesCheckBox.Checked == true)
            {
                YesCheckBox.Checked = false;
            }
        }
    }
}
