﻿using System;
using MySql.Data.MySqlClient;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace BOP1_Scheduling_Application
{
    public partial class UpdateAppointmentForm : Form
    {
        MySqlConnection Conn = new MySqlConnection(SQL.myConnectionString);
        MySqlDataReader mdr;
        SQL sql = new SQL();
        MainForm MainForm = new MainForm();
        public static int ind = 0;
        DataTable OverlapTable = new DataTable();
        public UpdateAppointmentForm()
        {
            InitializeComponent();
            string query = "Select * from appointment WHERE appointmentId = '" + SQL.AppointmentIndex + "';";
            Conn.Open();
            MySqlCommand command = new MySqlCommand(query, Conn);
            mdr = command.ExecuteReader();
            if (mdr.Read())
            {
                AppointmentIDTxtBox.Text = mdr.GetInt32("appointmentId").ToString();
                CustomerIDTxtBox.Text = mdr.GetInt32("customerId").ToString();
                AppointmentTypeTxtBox.Text = mdr.GetString("type");
                StartDateDateTime.Value = mdr.GetDateTime("start").ToLocalTime();
                EndDateDateTime.Value = mdr.GetDateTime("end").ToLocalTime();
            }
            String ID = TimeZoneInfo.Local.Id;
            if (ID == "Central Standard Time")
            {
                StartDateDateTime.Value = StartDateDateTime.Value.AddHours(5);
                EndDateDateTime.Value = EndDateDateTime.Value.AddHours(5);
            }
            else
            {
                if (ID == "Eastern Standard Time")
                {
                    StartDateDateTime.Value = StartDateDateTime.Value.AddHours(4);
                    EndDateDateTime.Value = EndDateDateTime.Value.AddHours(4);
                }
                else
                {
                    if (ID == "Mountain Standard Time")
                    {
                        StartDateDateTime.Value = StartDateDateTime.Value.AddHours(6);
                        EndDateDateTime.Value = EndDateDateTime.Value.AddHours(6);
                    }
                    else
                    {
                        if (ID == "Pacific Standard Time")
                        {
                            StartDateDateTime.Value = StartDateDateTime.Value.AddHours(7);
                            EndDateDateTime.Value = EndDateDateTime.Value.AddHours(7);
                        }
                    }
                }
            }

            Conn.Close();
            string Query = "SELECT start, end FROM appointment;";
            MySqlCommand cmd = new MySqlCommand(Query, Conn);
            Conn.Open();
            MySqlDataAdapter adapter = new MySqlDataAdapter();
            adapter.SelectCommand = cmd;
            adapter.Fill(OverlapTable);
            Conn.Close();
        }
    
        public bool IsOverlap(DateTime ST, DateTime ET, DateTime AST, DateTime AET)
        {
            return (ST < AST) ? (ET < AST) ? false : true : (ST > AET) ? false : true;
        }
        public Boolean CheckForOverlap()
        {

            for (ind = 0; ind < OverlapTable.Rows.Count; ind++)
            {
                DateTime Astart = TimeZoneInfo.ConvertTimeFromUtc((DateTime)OverlapTable.Rows[ind]["start"], TimeZoneInfo.Local);
                DateTime Aend = TimeZoneInfo.ConvertTimeFromUtc((DateTime)OverlapTable.Rows[ind]["end"], TimeZoneInfo.Local);
                DateTime Start = StartDateDateTime.Value.ToLocalTime();
                DateTime End = EndDateDateTime.Value.ToLocalTime();
                if (IsOverlap(Start, End, Astart, Aend))
                {
                    return true;

                }

            }
            return false;
        }
        private void CancelBtn_Click(object sender, EventArgs e)
        {
            MainForm mainForm = new MainForm();
            this.Hide();
            mainForm.Show();
        }

        private void UpdateAppointmentForm_Load(object sender, EventArgs e)
        {
            AppointmentIDTxtBox.Enabled = false;
        }

        private void UpdateAppointmentBtn_Click(object sender, EventArgs e)
        {
            if (StartDateDateTime.Value.TimeOfDay < SQL.Open.TimeOfDay || StartDateDateTime.Value.TimeOfDay > SQL.Close.TimeOfDay || EndDateDateTime.Value.TimeOfDay > SQL.Close.TimeOfDay || EndDateDateTime.Value.TimeOfDay < SQL.Open.TimeOfDay)
            {
                sql.HandleOustideBusinessHours();
            }
            else
                if (CheckForOverlap())
            {
                MessageBox.Show("The Appointment you have tried to schedule overlaps a currently scheduled appointment please try again.", "Appointment Overlap", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
            else
            {
                try
                {
                    int ApptID = Convert.ToInt32(AppointmentIDTxtBox.Text);
                    int CustomerId = Convert.ToInt32(CustomerIDTxtBox.Text);
                    string apptType = AppointmentTypeTxtBox.Text;
                    DateTime start = StartDateDateTime.Value.ToLocalTime();
                    DateTime end = EndDateDateTime.Value.ToLocalTime();
                    DateTime lastUpdate = DateTime.Now.ToLocalTime();
                    string lastUpdateBy = "test";

                    sql.UpdateAppointment(new Appointment(ApptID, CustomerId, apptType, start, end, lastUpdate, lastUpdateBy));
                    MainForm.Show();
                    this.Hide();
                }
                catch (FormatException F)
                {
                    MessageBox.Show(F.Message, "Format Exception", MessageBoxButtons.OK, MessageBoxIcon.Error);
                }
            }
           
        }
        private void isDayLight()
        {
            TimeZoneInfo LocalTZ = TimeZoneInfo.Local;

            if (LocalTZ.IsDaylightSavingTime(DateTime.SpecifyKind(StartDateDateTime.Value, DateTimeKind.Local)))
            {
                StartDateDateTime.Value.AddHours(1);
                EndDateDateTime.Value.AddHours(1);
            }
        }
    }
}
