﻿using System;
using System.Globalization;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;
using MySql.Data.MySqlClient;
using System.Reflection;
using System.Resources;


namespace BOP1_Scheduling_Application
{
    public partial class LoginForm : Form
    {

        public LoginForm()
        {
            InitializeComponent();
            timer1.Start();
        }

        public void CheckCurrentCulture(string s)
        {
            if (s == "es-ES")
            {
                UsernameLabel.Text = "Iniciar sesión";
                PasswordLbl.Text = "contraseña";
                LoginBtn.Text = "Iniciar sesión";
                ExitButton.Text = "Salida";
            }
        }
        private void ExitButton_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }

        private void LoginBtn_Click(object sender, EventArgs e)
        {
            ActivityLog activityLog = new ActivityLog();
            MySqlDataReader dr;
            MySqlCommand cmd;
            MySqlConnection conn;
            string Query = "Select * from user Where userName = '" + UsernameTextBox.Text + "' and password = '" + PasswordTextBox.Text + "'";
            string myConnectionString = "server=3.227.166.251;database=U05lUM;user=U05lUM;pwd=53688540322";

            conn = new MySqlConnection();
            conn.ConnectionString = myConnectionString;
            conn.Open();
            cmd = new MySqlCommand();
            cmd.Connection = conn;
            cmd.CommandText = Query;
            dr = cmd.ExecuteReader();
            if (dr.Read())
            {
                MainForm mainForm = new MainForm();
                this.Hide();
                mainForm.Show();
            }
            else
            {
                if (Thread.CurrentThread.CurrentCulture.Name == "es-ES")
                {
                    MessageBox.Show("Error de inicio de sesión. Compruebe su nombre de usuario y contraseña", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                }
                else
                {
                    MessageBox.Show(ErrorMessage.LoginError, ErrorMessage.Fail, MessageBoxButtons.OK, MessageBoxIcon.Error);
                }
            }
            conn.Close();

            activityLog.RecordLogin();
        }

        private void timer1_Tick(object sender, EventArgs e)
        {
            CultureInfo newCult = Thread.CurrentThread.CurrentCulture;
            CheckCurrentCulture(newCult.ToString());

        }

        private void button1_Click_1(object sender, EventArgs e)
        {
            MessageBox.Show(Thread.CurrentThread.CurrentCulture.Name);
        }
    }
}

   


