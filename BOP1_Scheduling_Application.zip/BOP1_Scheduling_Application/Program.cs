﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading;
using System.Threading.Tasks;
using System.Windows.Forms;
using MySql.Data.MySqlClient;

namespace BOP1_Scheduling_Application
{
    static class Program
    {

        
        /// <summary>
        /// The main entry point for the application.
        /// </summary>
        [STAThread]
        static void Main()
        {
            
            Application.EnableVisualStyles();
            Application.SetCompatibleTextRenderingDefault(false);
            SQL Sql = new SQL();
            Sql.FillAppointmentList();
            Sql.FillCustomerList();
            Sql.FillAddressIDList();
            Application.Run(new LoginForm());

        }
    }
}
