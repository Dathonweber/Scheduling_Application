﻿namespace BOP1_Scheduling_Application
{
    partial class UpdateCustomerForm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.NoCheckBox = new System.Windows.Forms.CheckBox();
            this.YesCheckBox = new System.Windows.Forms.CheckBox();
            this.activelbl = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.AddressIDLBL = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.CustomerNameLbl = new System.Windows.Forms.Label();
            this.CustomerIdlbl = new System.Windows.Forms.Label();
            this.PhoneNumberTxtBox = new System.Windows.Forms.TextBox();
            this.ZipCodeTxtBox = new System.Windows.Forms.TextBox();
            this.AddressTxtBox = new System.Windows.Forms.TextBox();
            this.CustomerNameTxtBox = new System.Windows.Forms.TextBox();
            this.CustomerIDTxtBox = new System.Windows.Forms.TextBox();
            this.ExitBtn = new System.Windows.Forms.Button();
            this.UpdateCustomerBtn = new System.Windows.Forms.Button();
            this.AddressIDTxtBox = new System.Windows.Forms.TextBox();
            this.label3 = new System.Windows.Forms.Label();
            this.SuspendLayout();
            // 
            // NoCheckBox
            // 
            this.NoCheckBox.AutoSize = true;
            this.NoCheckBox.Location = new System.Drawing.Point(193, 159);
            this.NoCheckBox.Name = "NoCheckBox";
            this.NoCheckBox.Size = new System.Drawing.Size(40, 17);
            this.NoCheckBox.TabIndex = 19;
            this.NoCheckBox.Text = "No";
            this.NoCheckBox.UseVisualStyleBackColor = true;
            this.NoCheckBox.CheckedChanged += new System.EventHandler(this.NoCheckBox_CheckedChanged);
            // 
            // YesCheckBox
            // 
            this.YesCheckBox.AutoSize = true;
            this.YesCheckBox.Location = new System.Drawing.Point(143, 159);
            this.YesCheckBox.Name = "YesCheckBox";
            this.YesCheckBox.Size = new System.Drawing.Size(44, 17);
            this.YesCheckBox.TabIndex = 12;
            this.YesCheckBox.Text = "Yes";
            this.YesCheckBox.UseVisualStyleBackColor = true;
            this.YesCheckBox.CheckedChanged += new System.EventHandler(this.YesCheckBox_CheckedChanged);
            // 
            // activelbl
            // 
            this.activelbl.AutoSize = true;
            this.activelbl.Location = new System.Drawing.Point(91, 159);
            this.activelbl.Name = "activelbl";
            this.activelbl.Size = new System.Drawing.Size(37, 13);
            this.activelbl.TabIndex = 13;
            this.activelbl.Text = "Active";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(59, 264);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(78, 13);
            this.label2.TabIndex = 14;
            this.label2.Text = "Phone Number";
            // 
            // AddressIDLBL
            // 
            this.AddressIDLBL.AutoSize = true;
            this.AddressIDLBL.Location = new System.Drawing.Point(86, 194);
            this.AddressIDLBL.Name = "AddressIDLBL";
            this.AddressIDLBL.Size = new System.Drawing.Size(45, 13);
            this.AddressIDLBL.TabIndex = 15;
            this.AddressIDLBL.Text = "Address";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(91, 229);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(46, 13);
            this.label1.TabIndex = 16;
            this.label1.Text = "Zipcode";
            // 
            // CustomerNameLbl
            // 
            this.CustomerNameLbl.AutoSize = true;
            this.CustomerNameLbl.Location = new System.Drawing.Point(55, 89);
            this.CustomerNameLbl.Name = "CustomerNameLbl";
            this.CustomerNameLbl.Size = new System.Drawing.Size(82, 13);
            this.CustomerNameLbl.TabIndex = 17;
            this.CustomerNameLbl.Text = "Customer Name";
            // 
            // CustomerIdlbl
            // 
            this.CustomerIdlbl.AutoSize = true;
            this.CustomerIdlbl.Location = new System.Drawing.Point(72, 54);
            this.CustomerIdlbl.Name = "CustomerIdlbl";
            this.CustomerIdlbl.Size = new System.Drawing.Size(65, 13);
            this.CustomerIdlbl.TabIndex = 18;
            this.CustomerIdlbl.Text = "Customer ID";
            // 
            // PhoneNumberTxtBox
            // 
            this.PhoneNumberTxtBox.Location = new System.Drawing.Point(143, 264);
            this.PhoneNumberTxtBox.Name = "PhoneNumberTxtBox";
            this.PhoneNumberTxtBox.Size = new System.Drawing.Size(151, 20);
            this.PhoneNumberTxtBox.TabIndex = 21;
            // 
            // ZipCodeTxtBox
            // 
            this.ZipCodeTxtBox.Location = new System.Drawing.Point(143, 228);
            this.ZipCodeTxtBox.Name = "ZipCodeTxtBox";
            this.ZipCodeTxtBox.Size = new System.Drawing.Size(85, 20);
            this.ZipCodeTxtBox.TabIndex = 20;
            // 
            // AddressTxtBox
            // 
            this.AddressTxtBox.Location = new System.Drawing.Point(143, 192);
            this.AddressTxtBox.Name = "AddressTxtBox";
            this.AddressTxtBox.Size = new System.Drawing.Size(151, 20);
            this.AddressTxtBox.TabIndex = 11;
            // 
            // CustomerNameTxtBox
            // 
            this.CustomerNameTxtBox.Location = new System.Drawing.Point(143, 87);
            this.CustomerNameTxtBox.Name = "CustomerNameTxtBox";
            this.CustomerNameTxtBox.Size = new System.Drawing.Size(151, 20);
            this.CustomerNameTxtBox.TabIndex = 10;
            // 
            // CustomerIDTxtBox
            // 
            this.CustomerIDTxtBox.Enabled = false;
            this.CustomerIDTxtBox.Location = new System.Drawing.Point(143, 51);
            this.CustomerIDTxtBox.Name = "CustomerIDTxtBox";
            this.CustomerIDTxtBox.Size = new System.Drawing.Size(151, 20);
            this.CustomerIDTxtBox.TabIndex = 9;
            // 
            // ExitBtn
            // 
            this.ExitBtn.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.ExitBtn.Location = new System.Drawing.Point(300, 324);
            this.ExitBtn.Name = "ExitBtn";
            this.ExitBtn.Size = new System.Drawing.Size(83, 33);
            this.ExitBtn.TabIndex = 23;
            this.ExitBtn.Text = "Exit";
            this.ExitBtn.UseVisualStyleBackColor = true;
            this.ExitBtn.Click += new System.EventHandler(this.ExitBtn_Click);
            // 
            // UpdateCustomerBtn
            // 
            this.UpdateCustomerBtn.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.UpdateCustomerBtn.Location = new System.Drawing.Point(211, 324);
            this.UpdateCustomerBtn.Name = "UpdateCustomerBtn";
            this.UpdateCustomerBtn.Size = new System.Drawing.Size(83, 33);
            this.UpdateCustomerBtn.TabIndex = 22;
            this.UpdateCustomerBtn.Text = "Update";
            this.UpdateCustomerBtn.UseVisualStyleBackColor = true;
            this.UpdateCustomerBtn.Click += new System.EventHandler(this.UpdateCustomerBtn_Click);
            // 
            // AddressIDTxtBox
            // 
            this.AddressIDTxtBox.Enabled = false;
            this.AddressIDTxtBox.Location = new System.Drawing.Point(143, 123);
            this.AddressIDTxtBox.Name = "AddressIDTxtBox";
            this.AddressIDTxtBox.Size = new System.Drawing.Size(151, 20);
            this.AddressIDTxtBox.TabIndex = 10;
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(72, 124);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(59, 13);
            this.label3.TabIndex = 17;
            this.label3.Text = "Address ID";
            // 
            // UpdateCustomerForm
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(395, 369);
            this.Controls.Add(this.NoCheckBox);
            this.Controls.Add(this.YesCheckBox);
            this.Controls.Add(this.activelbl);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.AddressIDLBL);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.CustomerNameLbl);
            this.Controls.Add(this.CustomerIdlbl);
            this.Controls.Add(this.PhoneNumberTxtBox);
            this.Controls.Add(this.ZipCodeTxtBox);
            this.Controls.Add(this.AddressTxtBox);
            this.Controls.Add(this.AddressIDTxtBox);
            this.Controls.Add(this.CustomerNameTxtBox);
            this.Controls.Add(this.CustomerIDTxtBox);
            this.Controls.Add(this.ExitBtn);
            this.Controls.Add(this.UpdateCustomerBtn);
            this.Name = "UpdateCustomerForm";
            this.Text = "UpdateCustomerForm";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.CheckBox NoCheckBox;
        private System.Windows.Forms.CheckBox YesCheckBox;
        private System.Windows.Forms.Label activelbl;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label AddressIDLBL;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label CustomerNameLbl;
        private System.Windows.Forms.Label CustomerIdlbl;
        private System.Windows.Forms.TextBox PhoneNumberTxtBox;
        private System.Windows.Forms.TextBox ZipCodeTxtBox;
        private System.Windows.Forms.TextBox AddressTxtBox;
        private System.Windows.Forms.TextBox CustomerNameTxtBox;
        private System.Windows.Forms.TextBox CustomerIDTxtBox;
        private System.Windows.Forms.Button ExitBtn;
        private System.Windows.Forms.Button UpdateCustomerBtn;
        private System.Windows.Forms.TextBox AddressIDTxtBox;
        private System.Windows.Forms.Label label3;
    }
}