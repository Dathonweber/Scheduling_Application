﻿using MySql.Data.MySqlClient;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace BOP1_Scheduling_Application
{
    public partial class ReportsForm : Form
    {
        static string myConnectionString = "server=3.227.166.251;database=U05lUM;user=U05lUM;pwd=53688540322";
        MySqlConnection Conn = new MySqlConnection(myConnectionString);
        public static List<string> Reports = new List<string>();
        DataTable schedule = new DataTable();
       
      

        public ReportsForm()
        {
            InitializeComponent();
            Reports.Add("number of appointment types by month");
            Reports.Add("Consultant Schedule");
            Reports.Add("Number Of Active Customers");
            ReportsDataGridView.DefaultCellStyle.SelectionBackColor = ReportsDataGridView.DefaultCellStyle.BackColor;
            ReportsDataGridView.DefaultCellStyle.SelectionForeColor = ReportsDataGridView.DefaultCellStyle.ForeColor;
            ReportsDataGridView.ColumnHeadersDefaultCellStyle.Font = new Font("Microsoft Sans Serif", 10, FontStyle.Regular);
            ReportsDataGridView.DefaultCellStyle.Font = new Font("Microsoft Sans Serif", 10, FontStyle.Regular);
            ReportsDataGridView.RowHeadersVisible = false;
            ReportsDataGridView.ClearSelection();
            ReportsDataGridView.ColumnHeadersDefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleCenter;
            ReportsComboBox.DataSource = Reports;
            ReportsComboBox.SelectedItem = null;
            
        }

         public void TypesByMonth()
        {
            string[] Months = new string[] { "January", "February", "March", "April", "May", "June", "July", "August", "September", "October", "November", "December" };
            string Query = "Select * From appointment";
            MySqlCommand cmd = new MySqlCommand(Query, Conn);
            MySqlDataAdapter adp = new MySqlDataAdapter(cmd);
            DataTable dt = new DataTable();
            adp.Fill(dt);
            ReportsDataGridView.DataSource = dt;
            ReportsDataGridView.Columns["title"].Visible = false;
            ReportsDataGridView.Columns["description"].Visible = false;
            ReportsDataGridView.Columns["location"].Visible = false;
            ReportsDataGridView.Columns["contact"].Visible = false;
            ReportsDataGridView.Columns["url"].Visible = false;
            ReportsDataGridView.Columns["createDate"].Visible = false;
            ReportsDataGridView.Columns["createdBy"].Visible = false;
            ReportsDataGridView.Columns["lastUpdate"].Visible = false;
            ReportsDataGridView.Columns["lastUpdateBy"].Visible = false;
            ReportsDataGridView.Columns["customerId"].Visible = false;
            ReportsDataGridView.Columns["end"].Visible = false;
            ReportsDataGridView.Columns["userId"].Visible = false;


            TxtReport.Text = "Report: Number of appointment types by Month,\r\n\r\n";

            foreach (string month in Months)
            {
                TxtReport.Text = TxtReport.Text + month + "\r\n";
                int numPres = 0;
                int numScrum = 0;
                int numCheckUp = 0;
                int other = 0;
                foreach (DataRow row in dt.Rows)
                {
                    if (month == Months[((DateTime)row["start"]).Month -1])
                    {
                        if (row["type"].ToString() == "Presentation")
                        {
                            numPres++;
                        }
                        if (row["type"].ToString() == "Scrum")
                        {
                            numScrum++;
                        }
                        if (row["type"].ToString() == "Checkup")
                        {
                            numCheckUp++;
                        }
                        if (row["type"].ToString() != "Checkup" && row["type"].ToString() != "Scrum" && row["type"].ToString() != "Presentation")
                        {
                            other++;
                        }
                    }
                }
                TxtReport.Text = TxtReport.Text +
                    "\tPresentation " + numPres + "\r\n" +
                    "\tScrum\t" + numScrum + "\r\n" +
                    "\tCheckup\t" + numCheckUp + "\r\n" +
                    "\tOther\t" + other + "\r\n";
                TxtReport.Select(0, 0);
            }
        }

        public void Schedule()
        {
            string query = "SELECT * FROM appointment;";
            MySqlCommand cmd = new MySqlCommand(query, Conn);
            Conn.Open();
            MySqlDataAdapter adapter = new MySqlDataAdapter();
            adapter.SelectCommand = cmd;
            adapter.Fill(schedule);
            Conn.Close();
            ReportsDataGridView.DataSource = schedule;

            ReportsDataGridView.Columns["userId"].DisplayIndex = 0;
            ReportsDataGridView.Columns["userId"].HeaderText = "Consultant";
            ReportsDataGridView.Columns["appointmentId"].HeaderText = "Appt. ID";
            ReportsDataGridView.Columns["title"].Visible = false;
            ReportsDataGridView.Columns["description"].Visible = false;
            ReportsDataGridView.Columns["location"].Visible = false;
            ReportsDataGridView.Columns["contact"].Visible = false;
            ReportsDataGridView.Columns["url"].Visible = false;
            ReportsDataGridView.Columns["createDate"].Visible = false;
            ReportsDataGridView.Columns["createdBy"].Visible = false;
            ReportsDataGridView.Columns["lastUpdate"].Visible = false;
            ReportsDataGridView.Columns["lastUpdateBy"].Visible = false;
            ReportsDataGridView.Columns["customerId"].Visible = false;
            ReportsDataGridView.Columns["type"].Visible = false;
            ReportsDataGridView.Columns["end"].Visible = false;

            ReportsDataGridView.Sort(ReportsDataGridView.Columns["start"], ListSortDirection.Ascending);
        }

       public void ActiveCustomers()
        {
            string query = "SELECT active, count(*) from customer group by active;";
            MySqlCommand cmd = new MySqlCommand(query, Conn);
            DataTable dt = new DataTable();
            MySqlDataAdapter adapter = new MySqlDataAdapter(cmd);
            adapter.Fill(dt);
            ReportsDataGridView.DataSource = dt;
            ReportsDataGridView.Columns["count(*)"].HeaderText = "Number of Customers";


        }

        private void RunReportBtn_Click(object sender, EventArgs e)
        {
            if (ReportsComboBox.SelectedIndex == 0)
            {
                TypesByMonth();
            }
            else if (ReportsComboBox.SelectedIndex == 1)
            {
                Schedule();
            }
            else if (ReportsComboBox.SelectedIndex == 2)
            {
                ActiveCustomers();
            }
            else
            {
                MessageBox.Show("Please Select a Report to Run");
            }
        }

        private void ExitButton_Click(object sender, EventArgs e)
        {
            MainForm mf = new MainForm();
            mf.Show();
            this.Hide();
        }
    }
}
