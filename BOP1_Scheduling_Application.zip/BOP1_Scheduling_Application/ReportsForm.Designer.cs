﻿namespace BOP1_Scheduling_Application
{
    partial class ReportsForm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.ReportsDataGridView = new System.Windows.Forms.DataGridView();
            this.ReportsComboBox = new System.Windows.Forms.ComboBox();
            this.ReportsLabel = new System.Windows.Forms.Label();
            this.OptionsLabel = new System.Windows.Forms.Label();
            this.ExitButton = new System.Windows.Forms.Button();
            this.RunReportBtn = new System.Windows.Forms.Button();
            this.TxtReport = new System.Windows.Forms.TextBox();
            ((System.ComponentModel.ISupportInitialize)(this.ReportsDataGridView)).BeginInit();
            this.SuspendLayout();
            // 
            // ReportsDataGridView
            // 
            this.ReportsDataGridView.AllowUserToAddRows = false;
            this.ReportsDataGridView.AllowUserToDeleteRows = false;
            this.ReportsDataGridView.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.Fill;
            this.ReportsDataGridView.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.ReportsDataGridView.Location = new System.Drawing.Point(236, 52);
            this.ReportsDataGridView.Name = "ReportsDataGridView";
            this.ReportsDataGridView.ReadOnly = true;
            this.ReportsDataGridView.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
            this.ReportsDataGridView.Size = new System.Drawing.Size(443, 384);
            this.ReportsDataGridView.TabIndex = 0;
            // 
            // ReportsComboBox
            // 
            this.ReportsComboBox.FormattingEnabled = true;
            this.ReportsComboBox.Location = new System.Drawing.Point(10, 137);
            this.ReportsComboBox.Name = "ReportsComboBox";
            this.ReportsComboBox.Size = new System.Drawing.Size(218, 21);
            this.ReportsComboBox.TabIndex = 1;
            // 
            // ReportsLabel
            // 
            this.ReportsLabel.AutoSize = true;
            this.ReportsLabel.Font = new System.Drawing.Font("Microsoft Sans Serif", 27.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.ReportsLabel.Location = new System.Drawing.Point(535, 7);
            this.ReportsLabel.Name = "ReportsLabel";
            this.ReportsLabel.Size = new System.Drawing.Size(180, 42);
            this.ReportsLabel.TabIndex = 2;
            this.ReportsLabel.Text = "REPORT";
            // 
            // OptionsLabel
            // 
            this.OptionsLabel.AutoSize = true;
            this.OptionsLabel.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.OptionsLabel.Location = new System.Drawing.Point(33, 111);
            this.OptionsLabel.Name = "OptionsLabel";
            this.OptionsLabel.Size = new System.Drawing.Size(173, 20);
            this.OptionsLabel.TabIndex = 3;
            this.OptionsLabel.Text = "Choose Your Report";
            // 
            // ExitButton
            // 
            this.ExitButton.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.ExitButton.Location = new System.Drawing.Point(924, 453);
            this.ExitButton.Name = "ExitButton";
            this.ExitButton.Size = new System.Drawing.Size(90, 38);
            this.ExitButton.TabIndex = 4;
            this.ExitButton.Text = "Exit";
            this.ExitButton.UseVisualStyleBackColor = true;
            this.ExitButton.Click += new System.EventHandler(this.ExitButton_Click);
            // 
            // RunReportBtn
            // 
            this.RunReportBtn.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.RunReportBtn.Location = new System.Drawing.Point(67, 232);
            this.RunReportBtn.Name = "RunReportBtn";
            this.RunReportBtn.Size = new System.Drawing.Size(105, 38);
            this.RunReportBtn.TabIndex = 4;
            this.RunReportBtn.Text = "Run Report";
            this.RunReportBtn.UseVisualStyleBackColor = true;
            this.RunReportBtn.Click += new System.EventHandler(this.RunReportBtn_Click);
            // 
            // TxtReport
            // 
            this.TxtReport.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.TxtReport.Location = new System.Drawing.Point(711, 52);
            this.TxtReport.Multiline = true;
            this.TxtReport.Name = "TxtReport";
            this.TxtReport.ReadOnly = true;
            this.TxtReport.ScrollBars = System.Windows.Forms.ScrollBars.Vertical;
            this.TxtReport.Size = new System.Drawing.Size(289, 384);
            this.TxtReport.TabIndex = 5;
            // 
            // ReportsForm
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1026, 503);
            this.Controls.Add(this.TxtReport);
            this.Controls.Add(this.RunReportBtn);
            this.Controls.Add(this.ExitButton);
            this.Controls.Add(this.OptionsLabel);
            this.Controls.Add(this.ReportsLabel);
            this.Controls.Add(this.ReportsComboBox);
            this.Controls.Add(this.ReportsDataGridView);
            this.Name = "ReportsForm";
            this.Text = "ReportsForm";
            ((System.ComponentModel.ISupportInitialize)(this.ReportsDataGridView)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion
        private System.Windows.Forms.ComboBox ReportsComboBox;
        private System.Windows.Forms.Label ReportsLabel;
        private System.Windows.Forms.Label OptionsLabel;
        private System.Windows.Forms.Button ExitButton;
        private System.Windows.Forms.Button RunReportBtn;
        public System.Windows.Forms.DataGridView ReportsDataGridView;
        private System.Windows.Forms.TextBox TxtReport;
    }
}